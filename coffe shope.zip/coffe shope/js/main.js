let menu = document.querySelector('#menu-btn');
let navbar = document.querySelector('.header .flex .navbar');

menu.onclick = () => {
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');
};

window.onscroll = () => {
    menu.classList.remove('fa-times');
    navbar.classList.remove('active');
};

/* ===============================
   BOOKING FORM BACKEND CONNECTION
   =============================== */

const form = document.getElementById("contactForm");
const msg = document.getElementById("formMsg");

form.addEventListener("submit", async (e) => {
    e.preventDefault();

    msg.style.color = "black";
    msg.textContent = "Submitting...";

    const data = {
        name: form.name.value,
        phone: form.phone.value,
        guest: form.guest.value
    };

    try {
        const res = await fetch(
            "https://ty1y57r4id.execute-api.eu-north-1.amazonaws.com/book-table",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(data)
            }
        );

        const result = await res.json();

        if (res.ok) {
            msg.style.color = "green";
            msg.textContent = "Booking saved successfully!";
            form.reset();
        } else {
            throw new Error(result.message || "Server error");
        }

    } catch (err) {
        msg.style.color = "red";
        msg.textContent = "Server Error. Please Try Again.";
        console.error(err);
    }
});
